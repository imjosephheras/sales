<head>
  <meta charset="UTF-8">
  <title>Cost Calculator | Prime Facility Services</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">

  <style>
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
    }

    body {
      font-family: 'Inter', sans-serif;
      background: linear-gradient(135deg, #03194e 0%, #48577f 100%);
      min-height: 100vh;
      padding: 20px;
      color: #333;
    }

    .container-calculator {
      max-width: 1100px;
      margin: 0 auto;
      padding: 20px;
      background: #ffffff;
      border-radius: 20px;
      box-shadow: 0 5px 20px rgba(0,0,0,0.12);
    }

    .question-block label {
      font-weight: 600;
      margin-bottom: 5px;
      display: block;
    }

    input, select {
      width: 100%;
      background: #f6f7f9;
      border: 1px solid #c9ccd1;
      border-radius: 8px;
      padding: 10px 12px;
      font-size: 14px;
      margin-bottom: 15px;
    }

    input[readonly] {
      background: #f1f1f1;
    }

    table {
      width: 100%;
      border-collapse: collapse;
      margin-top: 15px;
      border-radius: 12px;
      overflow: hidden;
    }

    table thead {
      background: linear-gradient(135deg,#c70734 0%,#8b0000 100%);
      color: #fff;
    }

    table th, table td {
      padding: 10px;
      border-bottom: 1px solid #ececec;
    }

    .section-bar {
      background: linear-gradient(180deg,#0b2a57 0%,#071d3a 100%);
      color: #fff;
      padding: 12px 16px;
      border-radius: 6px;
      font-weight: 700;
      text-transform: uppercase;
      display: flex;
      justify-content: space-between;
      cursor: pointer;
      margin: 25px 0 10px;
    }

    .section-content {
      padding: 10px 5px 5px;
    }

    .markup-bar-wrapper {
      position: relative;
      margin-bottom: 10px;
    }

    .markup-slider {
      position: absolute;
      inset: 0;
      height: 32px;
      opacity: 0;
      cursor: pointer;
      z-index: 3;
    }

    .markup-bar {
      height: 32px;
      background: #e6e9ef;
      border-radius: 20px;
      overflow: hidden;
    }

    .markup-fill {
      height: 100%;
      width: 0%;
      background: linear-gradient(90deg,#0b2a57,#1e4fa3);
      display: flex;
      align-items: center;
      justify-content: center;
      color: #fff;
      font-weight: 700;
    }

    #profitGauge {
      max-width: 220px;
      margin: 0 auto;
      display: block;
    }
  </style>

<style>
/* =========================
   BASE (PANTALLA)
   print-only NUNCA se ve
========================= */
.print-only {
    display: none;
}

/* =========================
   PRINT MODE
========================= */
@media print {

    /* 🔥 FORZAR COLORES REALES */
    * {
        -webkit-print-color-adjust: exact !important;
        print-color-adjust: exact !important;
    }

    body {
        background: #ffffff !important;
    }

    /* =========================
       FORZAR TODO ABIERTO
       (ignora toggles)
    ========================= */
    .section-content {
        display: block !important;
    }

    /* 🔥 Forzar bloques específicos */
    #q_hood_vent,
    #q_labor_table,
    #q2,
    #q3,
    #q4,
    #q5,
    #q6,
    #subcontractor_price_block {
        display: block !important;
    }

    /* ❌ Ocultar controles interactivos */
    button,
    select,
    input,
    .no-print {
        display: none !important;
    }

    /* =========================
       PRINT-ONLY COMO INPUT
    ========================= */
    .print-only {
        display: block !important;
        width: 100%;
        min-height: 40px;
        padding: 10px 12px;
        margin-top: 4px;

        background: #f6f7f9 !important;
        border: 1px solid #c9ccd1 !important;
        border-radius: 8px;

        font-size: 14px;
        font-weight: 500;
        color: #333;

        box-sizing: border-box;
    }

    /* =========================
       COLORES AZULES DE MÓDULOS
    ========================= */

    /* Barras de sección */
    .section-bar {
        background: linear-gradient(180deg,#0b2a57 0%,#071d3a 100%) !important;
        color: #ffffff !important;
    }

    .section-bar span {
        color: #ffffff !important;
    }

    /* Barra de markup */
    .markup-bar {
        background: #e6e9ef !important;
    }

    /* Relleno azul del markup */
    .markup-fill {
        background: linear-gradient(90deg,#0b2a57,#1e4fa3) !important;
        color: #ffffff !important;
    }

    /* Labels del porcentaje */
    #markupLabel,
    #subcontractMarkupLabel,
    #markupLabelPrint,
    #subcontractMarkupLabelPrint {
        color: #ffffff !important;
        font-weight: 600;
    }
}
</style>


<style>
.print-btn {
  background: linear-gradient(135deg,#0b2a57,#1e4fa3);
  color: #fff;
  border: none;
  padding: 10px 16px;
  border-radius: 8px;
  font-weight: 600;
  cursor: pointer;
  margin-top: 20px;
}
.print-btn:hover {
  opacity: 0.9;
}
</style>



<script>
  /* ⛔ DETECTAR IMPRESIÓN */
const IS_PRINTING =
  window.matchMedia &&
  window.matchMedia('print').matches;
/* =====================================================
   TOGGLE SECTIONS
===================================================== */
function toggleSection(id, icon) {
  const el = document.getElementById(id);
  if (!el) return;

  const open = el.style.display !== "none";
  el.style.display = open ? "none" : "block";
  if (icon) icon.textContent = open ? "▲" : "▼";
}

/* =====================================================
   LABOR TABLE → LABOR COST
===================================================== */
function calculateLaborCostFromTable() {
  let total = 0;

  document.querySelectorAll('select[name="labor_workers[]"]').forEach((w, i) => {
    const h = document.querySelectorAll('select[name="labor_hours[]"]')[i];
    const r = document.querySelectorAll('input[name="labor_rate[]"]')[i];
    const d = document.querySelectorAll('select[name="labor_days[]"]')[i];

    total += (+w.value || 0) *
             (+h.value || 0) *
             (+r.value || 0) *
             (+d.value || 0);
  });

  const laborEl = document.querySelector('[name="Labor_Cost"]');
  if (laborEl) {
    laborEl.value = total.toFixed(2);

    // 🪞 print mirror (ESTO ES LO QUE FALTABA)
    const span = laborEl.nextElementSibling;
    if (span && span.classList.contains('print-only')) {
      span.textContent = laborEl.value;
    }
  }

  calculateFringe();
  calculateDirectSubtotal();
}


/* =====================================================
   FRINGE (Tx, Insurance, Benefits)
===================================================== */
function calculateFringe() {
  const labor =
    +document.querySelector('[name="Labor_Cost"]')?.value || 0;

  const fringe = labor * 0.1993;

  const fringeEl = document.getElementById('labor_fringe');
  if (fringeEl) {
    fringeEl.value = fringe.toFixed(2);

    // 🪞 PRINT MIRROR (ESTO FALTABA)
    const span = fringeEl.nextElementSibling;
    if (span && span.classList.contains('print-only')) {
      span.textContent = fringeEl.value;
    }
  }
}


/* =====================================================
   HOOD VENT TOTAL (PRECIO DE VENTA)
===================================================== */
function calculateHoodVentDisplayedTotal() {
  const hoodBlock = document.getElementById('q_hood_vent');
  if (!hoodBlock) return 0;

  let total = 0;

  hoodBlock.querySelectorAll('select[name="hood_qty[]"]').forEach((q, i) => {
    const p = hoodBlock.querySelectorAll('select[name="hood_price[]"]')[i];
    total += (+q.value || 0) * (+p?.value || 0);
  });

  const out = document.getElementById('HoodVent_Total');
  if (out) out.value = total.toFixed(2);

  return total;
}

/* =====================================================
   UI: mostrar/ocultar markup y total según Service Type
===================================================== */
function toggleMarkupByServiceType() {
  const type = document.querySelector('[name="Service_Type"]')?.value || "";

  const normalMarkupBlock = document.getElementById('normal_markup_block');
  const subcontractMarkupBlock = document.getElementById('subcontract_markup_block');

  const normalTotalBlock = document.getElementById('normal_total_block');
  const hoodTotalBlock = document.getElementById('hoodvent_total_block');

  // MARKUP blocks
  if (type === "subcontract") {
    if (normalMarkupBlock) normalMarkupBlock.style.display = "none";
    if (subcontractMarkupBlock) subcontractMarkupBlock.style.display = "block";
  } else {
    if (normalMarkupBlock) normalMarkupBlock.style.display = "block";
    if (subcontractMarkupBlock) subcontractMarkupBlock.style.display = "none";
  }

  // TOTAL blocks
  if (type === "hoodvent") {
    if (normalTotalBlock) normalTotalBlock.style.display = "none";
    if (hoodTotalBlock) hoodTotalBlock.style.display = "block";
  } else {
    if (normalTotalBlock) normalTotalBlock.style.display = "block";
    if (hoodTotalBlock) hoodTotalBlock.style.display = "none";
  }
}

/* =====================================================
   DIRECT SUBTOTAL (COSTO REAL)
===================================================== */
function calculateDirectSubtotal() {
  const serviceType =
    document.querySelector('[name="Service_Type"]')?.value || "";

  // SUBCONTRACT: Direct_Subtotal = Subcontract_Price
  if (serviceType === "subcontract") {
    const subcontract =
      +document.querySelector('[name="Subcontract_Price"]')?.value || 0;

    const directEl = document.querySelector('[name="Direct_Subtotal"]');
    if (directEl) {
      directEl.value = subcontract.toFixed(2);

      // 🪞 print mirror
      const span = directEl.nextElementSibling;
      if (span && span.classList.contains('print-only')) {
        span.textContent = directEl.value;
      }
    }

    calculateMarkup();
    return;
  }

  // TIMESHEET / HOODVENT COST BASE
  const values = [
    'Labor_Cost',
    'Labor_Fringe',
    'Transport_Cost',
    'Material_Cost',
    'Equipment_Cost'
  ].map(n => +document.querySelector(`[name="${n}"]`)?.value || 0);

  const subtotal = values.reduce((a, b) => a + b, 0);

  const directEl = document.querySelector('[name="Direct_Subtotal"]');
  if (directEl) {
    directEl.value = subtotal.toFixed(2);

    // 🪞 print mirror
    const span = directEl.nextElementSibling;
    if (span && span.classList.contains('print-only')) {
      span.textContent = directEl.value;
    }
  }

  calculateMarkup();
}


/* =====================================================
   MARKUP / TOTAL
===================================================== */
function calculateMarkup() {
  const serviceType =
    document.querySelector('[name="Service_Type"]')?.value || "";

  /* 🔴 HOODVENT */
  if (serviceType === "hoodvent") {
    const sellPrice = calculateHoodVentDisplayedTotal();
    const cost =
      +document.querySelector('[name="Direct_Subtotal"]')?.value || 0;

    const profit = sellPrice - cost;
    const percent = sellPrice > 0 ? (profit / sellPrice) * 100 : 0;

    const amountEl = document.querySelector('[name="Markup_Amount"]');
    const totalEl  = document.querySelector('[name="Total"]');

    if (amountEl) {
      amountEl.value = profit.toFixed(2);

      // 🪞 print mirror
      const span = amountEl.nextElementSibling;
      if (span && span.classList.contains('print-only')) {
        span.textContent = amountEl.value;
      }
    }

    if (totalEl) {
      totalEl.value = sellPrice.toFixed(2);

      // 🪞 print mirror
      const span = totalEl.nextElementSibling;
      if (span && span.classList.contains('print-only')) {
        span.textContent = totalEl.value;
      }
    }

    // % label
    const label = document.getElementById('markupLabel');
    const fill  = document.getElementById('markupFill');

    if (label) label.textContent = percent.toFixed(1) + '%';
    if (fill)  fill.style.width  = Math.min(Math.max(percent, 0), 100) + '%';

    // 🪞 print mirror % 
    const labelPrint = document.getElementById('markupLabelPrint');
    if (labelPrint) labelPrint.textContent = percent.toFixed(1) + '%';

    calculateTaxes();
    calculateFixedCosts();
    calculateProfitMarginGauge();
    return;
  }

  /* 🟡 SUBCONTRACT */
  if (serviceType === "subcontract") {

    const base =
      +document.querySelector('[name="Subcontract_Price"]')?.value || 0;

    const pct =
      +document.getElementById('SubcontractMarkupSlider')?.value || 0;

    const amount = base * pct / 100;
    const total  = base + amount;

    const directEl = document.querySelector('[name="Direct_Subtotal"]');
    if (directEl) directEl.value = base.toFixed(2);

    const amountEl = document.querySelector('[name="Markup_Amount"]');
    const totalEl  = document.querySelector('[name="Total"]');

    if (amountEl) {
      amountEl.value = amount.toFixed(2);

      const span = amountEl.nextElementSibling;
      if (span && span.classList.contains('print-only')) {
        span.textContent = amountEl.value;
      }
    }

    if (totalEl) {
      totalEl.value = total.toFixed(2);

      const span = totalEl.nextElementSibling;
      if (span && span.classList.contains('print-only')) {
        span.textContent = totalEl.value;
      }
    }

    const label = document.getElementById('subcontractMarkupLabel');
    const fill  = document.getElementById('subcontractMarkupFill');

    if (label) label.textContent = pct.toFixed(1) + '%';
    if (fill)  fill.style.width  = Math.min(Math.max(pct, 0), 100) + '%';

    // 🪞 print mirror %
    const labelPrint = document.getElementById('subcontractMarkupLabelPrint');
    if (labelPrint) labelPrint.textContent = pct.toFixed(1) + '%';

    calculateTaxes();
    calculateFixedCosts();
    calculateProfitMarginGauge();
    return;
  }

  /* 🟢 NORMAL / TIMESHEET */
  const base =
    +document.querySelector('[name="Direct_Subtotal"]')?.value || 0;

  const pct =
    +document.getElementById('MarkupSlider')?.value || 0;

  const amount = base * pct / 100;
  const total  = base + amount;

  const amountEl = document.querySelector('[name="Markup_Amount"]');
  const totalEl  = document.querySelector('[name="Total"]');

  if (amountEl) {
    amountEl.value = amount.toFixed(2);

    const span = amountEl.nextElementSibling;
    if (span && span.classList.contains('print-only')) {
      span.textContent = amountEl.value;
    }
  }

  if (totalEl) {
    totalEl.value = total.toFixed(2);

    const span = totalEl.nextElementSibling;
    if (span && span.classList.contains('print-only')) {
      span.textContent = totalEl.value;
    }
  }

  const label = document.getElementById('markupLabel');
  const fill  = document.getElementById('markupFill');

  if (label) label.textContent = pct.toFixed(1) + '%';
  if (fill)  fill.style.width  = Math.min(Math.max(pct, 0), 100) + '%';

  // 🪞 print mirror %
  const labelPrint = document.getElementById('markupLabelPrint');
  if (labelPrint) labelPrint.textContent = pct.toFixed(1) + '%';

  calculateTaxes();
  calculateFixedCosts();
  calculateProfitMarginGauge();
}

/* =====================================================
   TAXES
===================================================== */
/* =====================================================
   TAXES
===================================================== */
function calculateTaxes() {
  const total =
    +document.querySelector('[name="Total"]')?.value || 0;

  const taxesEl = document.querySelector('[name="Taxes"]');
  const grandEl = document.querySelector('[name="Grand_Total"]');

  if (taxesEl) {
    taxesEl.value = (total * 0.0825).toFixed(2);

    // 🪞 print mirror
    const span = taxesEl.nextElementSibling;
    if (span && span.classList.contains('print-only')) {
      span.textContent = taxesEl.value;
    }
  }

  if (grandEl) {
    grandEl.value = (total * 1.0825).toFixed(2);

    // 🪞 print mirror
    const span = grandEl.nextElementSibling;
    if (span && span.classList.contains('print-only')) {
      span.textContent = grandEl.value;
    }
  }
}


/* =====================================================
   FIXED COSTS
===================================================== */
function calculateFixedCosts() {

  const serviceType =
    document.querySelector('[name="Service_Type"]')?.value || "";

  let base = 0;

  /* ================================
     🟡 SUBCONTRACT
     → Fixed costs SOLO sobre la ganancia
  ================================ */
  if (serviceType === 'subcontract') {

    base =
      +document.querySelector('[name="Markup_Amount"]')?.value || 0;

  } else {

    /* 🟢 NORMAL / HOODVENT */
    const total =
      +document.querySelector('[name="Total"]')?.value || 0;

    const direct =
      +document.querySelector('[name="Direct_Subtotal"]')?.value || 0;

    base = total - direct;
  }

  const overhead  = base * 0.44;
  const netProfit = base * 0.56;

  const overheadEl = document.querySelector('[name="Overhead"]');
  const netEl      = document.querySelector('[name="Fixed_Subtotal"]');

  if (overheadEl) {
    overheadEl.value = overhead.toFixed(2);

    // 🪞 print mirror
    const span = overheadEl.nextElementSibling;
    if (span && span.classList.contains('print-only')) {
      span.textContent = overheadEl.value;
    }
  }

  if (netEl) {
    netEl.value = netProfit.toFixed(2);

    // 🪞 print mirror
    const span = netEl.nextElementSibling;
    if (span && span.classList.contains('print-only')) {
      span.textContent = netEl.value;
    }
  }
}


/* =====================================================
   PROFIT NET GAUGE (COLORED, 0–28%)
===================================================== */
function drawProfitGauge(percent) {
  const canvas = document.getElementById('profitGauge');
  if (!canvas) return;

  const ctx = canvas.getContext('2d');
  const w = canvas.width;
  const h = canvas.height;
  const cx = w / 2;
  const cy = h;
  const r = Math.min(w / 2, h) - 12;

  ctx.clearRect(0, 0, w, h);

  const MAX = 28;
  const safe = Math.max(0, Math.min(MAX, percent));

  function arc(from, to, color) {
    ctx.beginPath();
    ctx.arc(cx, cy, r, Math.PI + (from / MAX) * Math.PI, Math.PI + (to / MAX) * Math.PI);
    ctx.strokeStyle = color;
    ctx.lineWidth = 14;
    ctx.stroke();
  }

  arc(0, 10, '#c70734');
  arc(10, 18, '#f08c00');
  arc(18, 24, '#f2d200');
  arc(24, 28, '#2e9e44');

  const angle = Math.PI + (safe / MAX) * Math.PI;

  ctx.beginPath();
  ctx.moveTo(cx, cy);
  ctx.lineTo(cx + r * Math.cos(angle), cy + r * Math.sin(angle));
  ctx.strokeStyle = '#0b2a57';
  ctx.lineWidth = 3;
  ctx.stroke();

  ctx.beginPath();
  ctx.arc(cx, cy, 5, 0, Math.PI * 2);
  ctx.fillStyle = '#ffffff';
  ctx.fill();
}

/* =====================================================
   NET PROFIT MARGIN → GAUGE
===================================================== */
function calculateProfitMarginGauge() {
  const total = +document.querySelector('[name="Total"]')?.value || 0;
  const netProfit = +document.querySelector('[name="Fixed_Subtotal"]')?.value || 0;
  const label = document.getElementById('profitGaugeLabel');

  if (total <= 0) {
    drawProfitGauge(0);
    if (label) label.textContent = '0%';
    return;
  }

  const margin = (netProfit / total) * 100;
  drawProfitGauge(margin);
  if (label) label.textContent = margin.toFixed(1) + '%';
}

/* =====================================================
   EVENTS (GLOBAL)
===================================================== */
document.addEventListener('input', (e) => {

  // SUBCONTRACT PRICE
  if (e.target.name === 'Subcontract_Price') {
    calculateDirectSubtotal();
    return;
  }

  // TIMESHEET direct costs
  if (['Labor_Cost', 'Transport_Cost', 'Material_Cost', 'Equipment_Cost'].includes(e.target.name)) {
    calculateFringe();
    calculateDirectSubtotal();
    return;
  }

  // NORMAL slider (timesheet)
  if (e.target.id === 'MarkupSlider') {
    calculateMarkup();
    return;
  }

  // SUBCONTRACT slider
  if (e.target.id === 'SubcontractMarkupSlider') {
    calculateMarkup();
    return;
  }
});

document.addEventListener('change', (e) => {

  // HOODVENT table
  if (e.target.name === 'hood_qty[]' || e.target.name === 'hood_price[]') {
    calculateHoodVentDisplayedTotal();
    calculateMarkup();
    return;
  }

  // TIMESHEET labor table
  if (e.target.name?.includes('labor_')) {
    calculateLaborCostFromTable();
    return;
  }

  // Service type change (si existe input change)
  if (e.target.name === 'Service_Type') {
    toggleMarkupByServiceType();
    calculateDirectSubtotal();
    return;
  }
});

document.addEventListener('DOMContentLoaded', () => {
  toggleMarkupByServiceType();
  calculateHoodVentDisplayedTotal();
  calculateDirectSubtotal();
});
</script>
