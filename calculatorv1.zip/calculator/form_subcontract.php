<div class="section-title">Subcontractor Price</div>

<div class="question-block">
    <label>Subcontract Price ($)</label>

    <input type="number"
           name="Subcontract_Price"
           class="form-control">

    <span class="print-only"></span>
</div>
